import uuid
from datetime import datetime, timedelta
import openai
from user_management import users_collection
import tiktoken
# Function to calculate BMI
def calculate_bmi(weight, height):
    height_in_meters = height / 100  # Convert height to meters
    bmi = weight / (height_in_meters ** 2)
    return bmi

# Function to get completion from OpenAI
def get_completion(prompt, model="gpt-3.5-turbo"):
    messages = [{"role": "user", "content": prompt}]
    response = openai.ChatCompletion.create(
        model=model,
        messages=messages,
        temperature=0.5,  # Degree of randomness of the model's output
    )
    return response.choices[0].message["content"]

# Function to add a user
def add_user(age, height, weight, gender, goal, duration, health_issues, users_collection):
    user_id = str(uuid.uuid4())
    user_data = {
        'user_id': user_id,
        'age': age,
        'height': height,
        'weight': weight,
        'gender': gender,
        'goal': goal,
        'duration': duration,
        'health_issues': health_issues
    }
    users_collection.insert_one(user_data)
    return user_id

# Function to get past meals
def get_past_meals(user_id, recommendations_collection):
    thirty_days_ago = datetime.now() - timedelta(days=30)
    past_meals = recommendations_collection.find({
        'user_id': user_id,
        'date': {'$gte': thirty_days_ago}
    }, {'meal': 1, '_id': 0})
    return [meal['meal'] for meal in past_meals]

# Function for daily recommendation
def daily_recommendation(user_id, data_text, recommendations_collection):
    today = datetime.now().date()
    today_str = today.strftime('%Y-%m-%d')

    existing_meal = recommendations_collection.find_one({
        'user_id': user_id,
        'date': today_str
    }, {'meal': 1, '_id': 0})

    #if existing_meal:
        #meal = existing_meal['meal']
    #if:
    meal = generate_personalized_diet(user_id, today_str, data_text, recommendations_collection)
    
    return meal

def calculate_kilojoules_intake(age, height, weight, gender, goal, activity_level='sedentary'):
    # Calculate BMR
    if gender == 'male':
        bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)
    elif gender == 'female':
        bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age)
    else:
        raise ValueError("Gender must be 'male' or 'female'")

    # Adjust BMR for activity level
    activity_multipliers = {
        'sedentary': 1.2,
        'lightly_active': 1.375,
        'moderately_active': 1.55,
        'very_active': 1.725,
        'super_active': 1.9
    }

    if activity_level not in activity_multipliers:
        raise ValueError("Invalid activity level. Choose from: sedentary, lightly_active, moderately_active, very_active, super_active")

    total_kilojoules = bmr * activity_multipliers[activity_level]

    if goal > weight:  # Weight gain goal
        total_kilojoules += 500  # Add extra kilojoules for weight gain
    elif goal < weight:  # Weight loss goal
        total_kilojoules -= 500  # Subtract kilojoules for weight loss

    return total_kilojoules

def generate_personalized_diet(user_id, date, data_text, recommendations_collection):
    user_data = users_collection.find_one({'user_id': user_id})

    enc = tiktoken.get_encoding("gpt-3.5-turbo")
    data_tokens = len(enc.encode(data_text))

    if not user_data:
        raise ValueError(f"User with ID {user_id} does not exist.")
    
    age, height, weight, gender, goal, health_issues = user_data['age'], user_data['height'], user_data['weight'], user_data['gender'], user_data['goal'], user_data['health_issues']
    bmi = calculate_bmi(weight, height)
    
    # Calculate daily kilojoules intake
    kilojoules_needed = calculate_kilojoules_intake(age, height, weight, gender, goal)

    # Get past meals
    past_meals = get_past_meals(user_id, recommendations_collection)

    # If the data_text exceeds the maximum context length, summarize it
    if data_tokens > 16385:
        summary = summarize_text(data_text, max_length=16000)
    else:
        summary = data_text
    
    prompt = f"""
    User Information:
    - Age: {age}
    - Height: {height} cm
    - Weight: {weight} kg
    - Gender: {gender}
    - Goal: {goal} kg
    - Health Issues: {health_issues}
    - BMI: {bmi}
    - Daily Kilojoules Intake: {kilojoules_needed} kJ

    Past Meals (last month):
    {', '.join(past_meals)}

    Data Text Summary:
    {data_text[:80000]}  

    Please generate a 1-day meal plan based on the following requirements:
    User Information:
    - Age: {age}
    - Height: {height} cm
    - Weight: {weight} kg
    - Gender: {gender}
    - Goal: {goal} kg
    - Health Issues: {health_issues}
    - BMI: {bmi}
    - Daily Kilojoules Intake: {kilojoules_needed} kJ
    - Use only recipes from the Kenya Recipe Book 2018.txt and don't mention the Kenya Recipe Book 2018.txt!
    - Based on the goal to {goal} weight, recommend a diet using STRICTLY the Kenya Recipe Book 2018.txt. 
    - Avoid meals that include ingredients the user is intolerant to {health_issues}. 
    - Ensure that the total kilojoules for the day align with the user's daily intake needs.
    - Compare their Nutrition data per 100g of recipe on the Kenya Recipe Book 2018.txt.
    - Ensure that you do not do any repeatations for the meals consecutive requests.
    - Check the immediate past meals to avoid repetition.
    - Ensure variety!!!
    - Create a detailed schedule including:
      - Breakfast
      - Lunch
      - Dinner
      - Snacks
    - Provide portion sizes and timings for each meal.
    - Avoid repeating any meals from the past month.
    - Format the meal plan as follows:
      - Breakfast: [Meal name] - [Portion size] at [Time]
      - Lunch: [Meal name] - [Portion size] at [Time]
      - Dinner: [Meal name] - [Portion size] at [Time]
      - Snacks: [Meal name] - [Portion size] at [Time]
    """
    
    response = get_completion(prompt)
    
    recommendations_collection.insert_one({
        'user_id': user_id,
        'date': date,
        'meal': response
    })
    
    return response

def summarize_text(text, max_length=16000):
    # Use a text summarization model to summarize the input text
    # This is a placeholder function, you'll need to implement the actual summarization logic
    summary = text[:max_length]
    return summary
