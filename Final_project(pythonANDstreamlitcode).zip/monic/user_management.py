import uuid
from pymongo import MongoClient
from datetime import datetime, timedelta
import os


client = MongoClient('mongodb://localhost:27017')
db = client['diet_recommendations']
users_collection = db['users']
recommendations_collection = db['recommendations']

def add_user(age, height, weight, gender, goal, duration, health_issues):
    user_id = str(uuid.uuid4())
    user_data = {
        'user_id': user_id,
        'age': age,
        'height': height,
        'weight': weight,
        'gender': gender,
        'goal': goal,
        'duration': duration,
        'health_issues': health_issues
    }
    users_collection.insert_one(user_data)
    return user_id

# Retrieve past meals
def get_past_meals(user_id):
    thirty_days_ago = datetime.now() - timedelta(days=30)
    past_meals = recommendations_collection.find({
        'user_id': user_id,
        'date': {'$gte': thirty_days_ago}
    }, {'meal': 1, '_id': 0})
    return [meal['meal'] for meal in past_meals]