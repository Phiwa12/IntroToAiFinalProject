import streamlit as st
from data_loader import load_and_process_data, summarize_data
from user_management import add_user
from recommendation import daily_recommendation
from langchain_openai import OpenAIEmbeddings


# Load and process data
data, vectorstore = load_and_process_data("C:\\Users\\user\\Downloads\\Kenya Recipe Book 2018.txt")
data_text = summarize_data(data)

st.title("Diet Recommendation System")

# User Input
st.header("User Information")
age = st.number_input("Age", min_value=1, max_value=120)
height = st.number_input("Height (cm)", min_value=50, max_value=300)
weight = st.number_input("Weight (kg)", min_value=20, max_value=500)
gender = st.selectbox("Gender", ["male", "female"])
goal = st.number_input("Goal Weight (kg)", min_value=20, max_value=500)
duration = st.number_input("Duration (weeks)", min_value=1, max_value=52)
health_issues = st.text_input("Health Issues (comma-separated)")

if st.button("Get Recommendation"):
    # Add user and get recommendation
    user_id = add_user(age, height, weight, gender, goal, duration, health_issues)
    recommendation = daily_recommendation(user_id, data_text)
    
    st.header("Your Personalized Diet Plan")
    st.write(recommendation)

# Add some information about the system
st.sidebar.header("About")
st.sidebar.info("This diet recommendation system uses AI to generate personalized meal plans based on your information and health goals.")