def calculate_bmi(weight, height):
    return weight / ((height / 100) ** 2)

def calculate_kilojoules_intake(age, height, weight, gender, goal, activity_level='sedentary'):
    if gender == 'male':
        bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)
    elif gender == 'female':
        bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age)
    else:
        raise ValueError("Gender must be 'male' or 'female'")

    activity_multipliers = {
        'sedentary': 1.2,
        'lightly_active': 1.375,
        'moderately_active': 1.55,
        'very_active': 1.725,
        'super_active': 1.9
    }

    if activity_level not in activity_multipliers:
        raise ValueError("Invalid activity level. Choose from: sedentary, lightly_active, moderately_active, very_active, super_active")

    total_kilojoules = bmr * activity_multipliers[activity_level]

    if goal > weight:  # Weight gain goal
        total_kilojoules += 500  # Add extra kilojoules for weight gain
    elif goal < weight:  # Weight loss goal
        total_kilojoules -= 500  # Subtract kilojoules for weight loss

    return total_kilojoules