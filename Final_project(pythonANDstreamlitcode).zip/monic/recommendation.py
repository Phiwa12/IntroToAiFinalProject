from datetime import datetime
import openai
from user_management import users_collection, recommendations_collection, get_past_meals
from utils import calculate_bmi, calculate_kilojoules_intake
import os

openai.api_key = 'sk-proj-nx2fCMkFkbR0UVwlYoCMT3BlbkFJ4eiMK47mcR6PI460gI17'
os.environ["OPENAI_API_KEY"] = openai.api_key

def get_completion(prompt, model="gpt-3.5-turbo"):
    messages = [{"role": "user", "content": prompt}]
    response = openai.ChatCompletion.create(
        model=model,
        messages=messages,
        temperature=0,
    )
    return response.choices[0].message["content"]

def generate_personalized_diet(user_id, date, data_text):
    user_data = users_collection.find_one({'user_id': user_id})

    if not user_data:
        raise ValueError(f"User with ID {user_id} does not exist.")
    
    age, height, weight, gender, goal, health_issues = user_data['age'], user_data['height'], user_data['weight'], user_data['gender'], user_data['goal'], user_data['health_issues']
    bmi = calculate_bmi(weight, height)
    
    kilojoules_needed = calculate_kilojoules_intake(age, height, weight, gender, goal)

    past_meals = get_past_meals(user_id)
    
    prompt = f"""
User Profile:
- Age: {age}
- Height: {height} cm
- Weight: {weight} kg
- Gender: {gender}
- Weight Goal: {goal} kg
- Health Issues: {health_issues}
- BMI: {bmi}
- Daily Kilojoules Intake: {kilojoules_needed} kJ

Recent Meal History:
{', '.join(past_meals)}

Dietary Requirements:
1. Use only recipes from the Kenya Recipe Book 2018
2. Align with weight {goal} objective
3. Avoid allergens and foods related to {health_issues}
4. Match daily kilojoule intake to {kilojoules_needed} kJ
5. Ensure variety and avoid repeating meals from the past month

Meal Plan Guidelines:
1. Create a detailed 1-day schedule including:
   - Breakfast
   - Lunch
   - Dinner
   - Snacks
2. Provide portion sizes and timings for each meal
3. Compare nutritional data per 100g of recipe
4. Ensure no consecutive meal repetitions

Formatting:
BREAKFAST > [Meal Type]: [Meal Name] - [Portion Size] at [Time]
LUNCH > [Meal Type]: [Meal Name] - [Portion Size] at [Time]
DINNER > [Meal Type]: [Meal Name] - [Portion Size] at [Time]
SNACKS > [Meal Type]: [Meal Name] - [Portion Size] at [Time]
Additional Notes:
- Do not mention the Kenya Recipe Book 2018 explicitly
- Prioritize variety in meal selections

Data Summary:
{data_text[:80000]}

Please generate a 1-day meal plan based on the above information and guidelines.
"""
    
    response = get_completion(prompt)
    
    recommendations_collection.insert_one({
        'user_id': user_id,
        'date': date,
        'meal': response
    })
    
    return response
#function to get daily recommendations
def daily_recommendation(user_id, data_text):
    today = datetime.now().date()
    today_str = today.strftime('%Y-%m-%d')

    existing_meal = recommendations_collection.find_one({
        'user_id': user_id,
        'date': today_str
    }, {'meal': 1, '_id': 0})

    if existing_meal:
        meal = existing_meal['meal']
    else:
        meal = generate_personalized_diet(user_id, today_str, data_text)
    
    return meal
