from langchain_community.document_loaders import TextLoader
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

def load_and_process_data(file_path):
    loader = TextLoader(file_path=file_path, encoding="utf-8")
    data = loader.load()
    
    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.from_documents(data, embedding=embeddings)
    
    return data, vectorstore

# Summarize data to avoid exceeding token limit
def summarize_data(data, max_length=900000):
    summarized_data = ""
    current_length = 0
    for doc in data:
        if current_length + len(doc.page_content) > max_length:
            break
        summarized_data += doc.page_content + "\n"
        current_length += len(doc.page_content)
    return summarized_data